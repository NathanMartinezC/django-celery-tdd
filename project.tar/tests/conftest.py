from pytest_factoryboy import register
from polls.factories import UserFactory

register(UserFactory)